// const express = require("express");
// const Router = express.Router();
// const user = require("../controllers/user/allotedSites");
// const admin = require("../controllers/admin/allotedSites");

// Router.route("/createAllotedSites").post(admin.createAllotedSites);

// //=================


// module.exports = Router;
