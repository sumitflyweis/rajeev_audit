// const mongoose = require("mongoose");
// const bcrypt = require("bcryptjs");
// const validator = require("validator");

// const allotedSitesSchema = new mongoose.Schema({
// SITE_ID:{
//     type:String
// },
//   clientName: {
//     type: String,
//     required: [true, "Please Enter your Client name"],
//   },
//   SiteAddress: {
//     type: String,
//     required: [true, "Please enter your siteaddress."],
//   },
//   ScheduledDate: {
//     type: String,
//     required: [true, "Please enter your Date"],
//   },
//   allotedCheckSheet:[ {
//     type: String,
//   }],

// });

// const sites = mongoose.model("allotedSites", allotedSitesSchema);

// module.exports = sites;
